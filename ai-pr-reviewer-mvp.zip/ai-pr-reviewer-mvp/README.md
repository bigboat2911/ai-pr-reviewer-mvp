# AI PR Reviewer MVP

一个可以直接运行的 GitHub PR 自动代码评审机器人。

它会在 PR opened / synchronize / reopened / ready_for_review 时：

1. 接收 GitHub Webhook
2. 校验 Webhook 签名
3. 拉取 PR diff
4. 过滤二进制、构建产物、lock 文件等低价值文件
5. 调用 OpenAI 模型做代码评审
6. 生成风险等级、总评、行级评论
7. 自动把 Review 发回 GitHub PR

---

## 目录结构

```text
ai-pr-reviewer-mvp/
  main.py
  requirements.txt
  .env.example
  README.md
  Dockerfile
  docker-compose.yml
  scripts/
    run_local.sh
```

---

## 方式一：本地 Python 运行

### 1. 创建虚拟环境

```bash
python -m venv .venv
source .venv/bin/activate
```

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

### 2. 安装依赖

```bash
pip install -r requirements.txt
```

### 3. 配置环境变量

```bash
cp .env.example .env
```

然后编辑 `.env`：

```env
GITHUB_TOKEN=ghp_xxx
GITHUB_WEBHOOK_SECRET=your_webhook_secret
OPENAI_API_KEY=sk_xxx
OPENAI_MODEL=gpt-4.1-mini
```

### 4. 启动服务

```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

打开健康检查：

```bash
curl http://localhost:8000/health
```

看到下面结果说明服务启动成功：

```json
{"status":"ok"}
```

---

## 方式二：Docker 运行

```bash
docker compose up --build
```

---

## 暴露到公网

本地开发可以用 ngrok：

```bash
ngrok http 8000
```

拿到类似下面的地址：

```text
https://xxxx.ngrok-free.app
```

Webhook URL 就填：

```text
https://xxxx.ngrok-free.app/github/webhook
```

---

## GitHub Webhook 配置

进入目标仓库：

```text
Settings -> Webhooks -> Add webhook
```

填写：

```text
Payload URL: https://你的域名/github/webhook
Content type: application/json
Secret: 和 .env 里的 GITHUB_WEBHOOK_SECRET 一致
Events: Pull requests
```

建议只勾选：

```text
Pull requests
```

---

## GitHub Token 权限

如果使用 classic PAT：

- 私有仓库：`repo`
- 公开仓库：`public_repo`

如果使用 fine-grained token，至少需要目标仓库的：

- Pull requests: Read and write
- Contents: Read-only
- Metadata: Read-only

---

## 测试方式

1. 启动服务。
2. 配置 GitHub Webhook。
3. 在目标仓库创建一个 PR。
4. 等待机器人在 PR 下发布 `AI PR Review`。

如果修改 PR，会触发 `synchronize`，机器人会重新评审。

---

## 成本与噪音控制

可在 `.env` 中调整：

```env
MAX_FILES=20
MAX_PATCH_CHARS=12000
MAX_REVIEW_COMMENTS=10
```

含义：

- `MAX_FILES`: 每个 PR 最多评审多少个文件
- `MAX_PATCH_CHARS`: 每个文件最多传给模型多少字符的 diff
- `MAX_REVIEW_COMMENTS`: 每个 PR 最多发布多少条行级评论

---

## 常见问题

### 1. Webhook 返回 401

通常是 `GITHUB_WEBHOOK_SECRET` 不一致。确保 GitHub Webhook Secret 和 `.env` 完全相同。

### 2. GitHub 返回 422

通常是行级评论的 line 不在 GitHub 可评论 diff 范围内。代码里已经做了降级：如果行级评论失败，会改成只发总评。

### 3. 没有评论

检查：

- PR 是否是 Draft
- Webhook 是否配置 Pull requests 事件
- `GITHUB_TOKEN` 是否有 Pull requests 写权限
- 服务日志是否有 OpenAI 或 GitHub API 错误

---

## 后续增强方向

这份 MVP 已经能跑。想让它更像生产级 Agent，可以继续加：

1. 仓库规则读取：读取 `CONTRIBUTING.md`、`README.md`、`.github/copilot-instructions.md`
2. 测试执行 Agent：自动触发 CI，并解释失败日志
3. RAG 知识库：接入团队架构文档和代码规范
4. 风险门禁：高风险时自动加 label 或要求人工 Review
5. 评论去重：避免同一个问题在多次 push 后重复评论
