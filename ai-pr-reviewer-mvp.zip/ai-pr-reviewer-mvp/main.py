from __future__ import annotations

import hashlib
import hmac
import json
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException, Request
from openai import OpenAI
from pydantic import BaseModel, Field, ValidationError

load_dotenv()

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN", "")
GITHUB_WEBHOOK_SECRET = os.getenv("GITHUB_WEBHOOK_SECRET", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
MAX_FILES = int(os.getenv("MAX_FILES", "20"))
MAX_PATCH_CHARS = int(os.getenv("MAX_PATCH_CHARS", "12000"))
MAX_REVIEW_COMMENTS = int(os.getenv("MAX_REVIEW_COMMENTS", "10"))

if not GITHUB_TOKEN:
    raise RuntimeError("Missing GITHUB_TOKEN")
if not GITHUB_WEBHOOK_SECRET:
    raise RuntimeError("Missing GITHUB_WEBHOOK_SECRET")
if not OPENAI_API_KEY:
    raise RuntimeError("Missing OPENAI_API_KEY")

app = FastAPI(title="AI PR Reviewer Bot", version="0.1.0")
openai_client = OpenAI(api_key=OPENAI_API_KEY)


class ReviewComment(BaseModel):
    path: str = Field(..., description="File path")
    line: int = Field(..., description="Line number on the new/right side of the diff")
    body: str = Field(..., description="Review comment body")
    severity: str = Field(default="medium", description="low | medium | high")


class AIReviewResult(BaseModel):
    summary: str
    risk_level: str = Field(description="low | medium | high")
    comments: List[ReviewComment]


@dataclass
class PullRequestContext:
    owner: str
    repo: str
    pull_number: int
    head_sha: str
    title: str
    body: str
    author: str


class GitHubClient:
    def __init__(self, token: str):
        self.base_url = "https://api.github.com"
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "ai-pr-reviewer-mvp",
        }

    async def get_pr_files(self, owner: str, repo: str, pull_number: int) -> List[Dict[str, Any]]:
        files: List[Dict[str, Any]] = []
        page = 1
        async with httpx.AsyncClient(timeout=30) as client:
            while True:
                url = f"{self.base_url}/repos/{owner}/{repo}/pulls/{pull_number}/files"
                resp = await client.get(url, headers=self.headers, params={"per_page": 100, "page": page})
                resp.raise_for_status()
                batch = resp.json()
                if not batch:
                    break
                files.extend(batch)
                if len(batch) < 100:
                    break
                page += 1
        return files

    async def create_pr_review(
        self,
        owner: str,
        repo: str,
        pull_number: int,
        commit_id: str,
        body: str,
        comments: List[ReviewComment],
    ) -> Dict[str, Any]:
        payload_comments = [
            {
                "path": c.path,
                "line": c.line,
                "side": "RIGHT",
                "body": f"[{c.severity.upper()}] {c.body}",
            }
            for c in comments
        ]
        payload = {
            "commit_id": commit_id,
            "body": body,
            "event": "COMMENT",
            "comments": payload_comments,
        }
        async with httpx.AsyncClient(timeout=30) as client:
            url = f"{self.base_url}/repos/{owner}/{repo}/pulls/{pull_number}/reviews"
            resp = await client.post(url, headers=self.headers, json=payload)
            if resp.status_code == 422 and payload_comments:
                fallback_payload = {
                    "commit_id": commit_id,
                    "body": body + "\n\nNote: Some inline comments could not be posted because GitHub rejected the diff line positions.",
                    "event": "COMMENT",
                }
                fallback_resp = await client.post(url, headers=self.headers, json=fallback_payload)
                fallback_resp.raise_for_status()
                return fallback_resp.json()
            resp.raise_for_status()
            return resp.json()


github = GitHubClient(GITHUB_TOKEN)


def verify_github_signature(raw_body: bytes, signature_header: Optional[str]) -> None:
    if not signature_header:
        raise HTTPException(status_code=401, detail="Missing GitHub signature")
    expected = "sha256=" + hmac.new(
        GITHUB_WEBHOOK_SECRET.encode("utf-8"),
        raw_body,
        hashlib.sha256,
    ).hexdigest()
    if not hmac.compare_digest(expected, signature_header):
        raise HTTPException(status_code=401, detail="Invalid GitHub signature")


def parse_pr_context(payload: Dict[str, Any]) -> PullRequestContext:
    repo_obj = payload["repository"]
    pr_obj = payload["pull_request"]
    return PullRequestContext(
        owner=repo_obj["owner"]["login"],
        repo=repo_obj["name"],
        pull_number=int(pr_obj["number"]),
        head_sha=pr_obj["head"]["sha"],
        title=pr_obj.get("title") or "",
        body=pr_obj.get("body") or "",
        author=pr_obj.get("user", {}).get("login", "unknown"),
    )


def filter_reviewable_files(files: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    ignored_suffixes = (
        ".lock", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg", ".pdf",
        ".zip", ".gz", ".mp4", ".mov", ".ico", ".min.js", ".map",
    )
    ignored_dirs = ("node_modules/", "dist/", "build/", "coverage/", "vendor/", ".next/", ".turbo/")
    result = []
    for f in files:
        filename = f.get("filename", "")
        patch = f.get("patch")
        status = f.get("status")
        if not patch or status == "removed":
            continue
        if filename.endswith(ignored_suffixes):
            continue
        if any(filename.startswith(d) for d in ignored_dirs):
            continue
        result.append(f)
    return result[:MAX_FILES]


def trim_patch(patch: str) -> str:
    if len(patch) <= MAX_PATCH_CHARS:
        return patch
    return patch[:MAX_PATCH_CHARS] + "\n... [patch truncated]"


def build_review_prompt(ctx: PullRequestContext, files: List[Dict[str, Any]]) -> str:
    file_blocks = []
    for f in files:
        file_blocks.append(
            f"""
File: {f.get('filename')}
Status: {f.get('status')}
Additions: {f.get('additions')}
Deletions: {f.get('deletions')}
Patch:
```diff
{trim_patch(f.get('patch', ''))}
```
""".strip()
        )
    return f"""
You are a senior code review agent reviewing a GitHub Pull Request.

Focus only on material issues:
1. Real bugs: null/None handling, boundary conditions, concurrency, errors, resource leaks.
2. Security risks: injection, authorization bypass, secret leakage, unsafe deserialization.
3. Performance risks: repeated queries, N+1, unbounded loops, large copies, blocking I/O.
4. Maintainability: confusing logic, duplicated code, misleading naming, missing tests.
5. Test suggestions for important paths.

Do not nitpick style. Do not invent context. Only comment on issues supported by the patch.
Inline comment line numbers must be on the new RIGHT side of the diff and close to added or modified lines.

PR title: {ctx.title}
PR author: {ctx.author}
PR body:
{ctx.body}

Changed files:
{chr(10).join(file_blocks)}

Return strict JSON only, with this shape:
{{
  "summary": "Overall PR assessment, key risks, and recommendation.",
  "risk_level": "low | medium | high",
  "comments": [
    {{
      "path": "src/example.py",
      "line": 42,
      "severity": "low | medium | high",
      "body": "Specific actionable review comment explaining the issue and a suggested fix."
    }}
  ]
}}
""".strip()


def call_ai_reviewer(ctx: PullRequestContext, files: List[Dict[str, Any]]) -> AIReviewResult:
    prompt = build_review_prompt(ctx, files)
    response = openai_client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=[
            {"role": "system", "content": "You are a pragmatic code review expert. Reduce production risk and avoid noisy comments."},
            {"role": "user", "content": prompt},
        ],
        temperature=0.2,
        response_format={"type": "json_object"},
    )
    content = response.choices[0].message.content or "{}"
    try:
        parsed = json.loads(content)
        return AIReviewResult.model_validate(parsed)
    except (json.JSONDecodeError, ValidationError) as exc:
        return AIReviewResult(
            summary=f"AI review result parsing failed: {exc}",
            risk_level="medium",
            comments=[],
        )


def build_review_body(result: AIReviewResult, reviewed_files: List[Dict[str, Any]]) -> str:
    file_list = ", ".join(f.get("filename", "") for f in reviewed_files[:10])
    if len(reviewed_files) > 10:
        file_list += f" and {len(reviewed_files) - 10} more"
    return f"""
## AI PR Review

Risk level: **{result.risk_level.upper()}**

{result.summary}

Reviewed files: {file_list or "No reviewable code files"}

> This is an automated review. Please validate recommendations against product and repository context.
""".strip()


@app.get("/health")
def health() -> Dict[str, str]:
    return {"status": "ok"}


@app.post("/github/webhook")
async def github_webhook(
    request: Request,
    x_github_event: Optional[str] = Header(default=None),
    x_hub_signature_256: Optional[str] = Header(default=None),
) -> Dict[str, Any]:
    raw_body = await request.body()
    verify_github_signature(raw_body, x_hub_signature_256)

    if x_github_event != "pull_request":
        return {"ok": True, "message": "ignored non pull_request event"}

    payload = json.loads(raw_body.decode("utf-8"))
    action = payload.get("action")
    if action not in {"opened", "synchronize", "reopened", "ready_for_review"}:
        return {"ok": True, "message": f"ignored action {action}"}

    pr = payload.get("pull_request", {})
    if pr.get("draft") is True:
        return {"ok": True, "message": "ignored draft PR"}

    ctx = parse_pr_context(payload)
    files = await github.get_pr_files(ctx.owner, ctx.repo, ctx.pull_number)
    reviewable_files = filter_reviewable_files(files)

    if not reviewable_files:
        result = AIReviewResult(summary="No reviewable code changes found.", risk_level="low", comments=[])
    else:
        result = call_ai_reviewer(ctx, reviewable_files)

    comments = sorted(
        result.comments,
        key=lambda c: {"high": 0, "medium": 1, "low": 2}.get(c.severity, 1),
    )[:MAX_REVIEW_COMMENTS]

    review_body = build_review_body(result, reviewable_files)
    created = await github.create_pr_review(
        owner=ctx.owner,
        repo=ctx.repo,
        pull_number=ctx.pull_number,
        commit_id=ctx.head_sha,
        body=review_body,
        comments=comments,
    )

    return {
        "ok": True,
        "owner": ctx.owner,
        "repo": ctx.repo,
        "pull_number": ctx.pull_number,
        "review_id": created.get("id"),
        "comment_count": len(comments),
        "risk_level": result.risk_level,
    }
